package com.example.lab3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final TextView ans = (TextView) findViewById(R.id.textView1);
        int n1,n2,res;


        Button b0 = (Button) findViewById(R.id.button0);
        b0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String exp = ans.getText().toString();
                ans.setText(exp + "0");
            }
        });

        Button b1 = (Button) findViewById(R.id.button1);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String exp = ans.getText().toString();
                ans.setText(exp + "1");
            }
        });

        Button b2 = (Button) findViewById(R.id.button2);
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String exp = ans.getText().toString();
                ans.setText(exp + "2");
            }
        });

        Button b3 = (Button) findViewById(R.id.button3);
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String exp = ans.getText().toString();
                ans.setText(exp + "3");
            }
        });

        Button b4 = (Button) findViewById(R.id.button4);
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String exp = ans.getText().toString();
                ans.setText(exp + "4");
            }
        });

        Button b5 = (Button) findViewById(R.id.button5);
        b5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String exp = ans.getText().toString();
                ans.setText(exp + "5");
            }
        });

        Button b6 = (Button) findViewById(R.id.button6);
        b6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String exp = ans.getText().toString();
                ans.setText(exp + "6");
            }
        });

        Button b7 = (Button) findViewById(R.id.button7);
        b7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String exp = ans.getText().toString();
                ans.setText(exp + "7");
            }
        });
        Button b8 = (Button) findViewById(R.id.button8);
        b8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String exp = ans.getText().toString();
                ans.setText(exp + "8");
            }
        });
        Button b9 = (Button) findViewById(R.id.button9);
        b9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String exp = ans.getText().toString();
                ans.setText(exp + "9");
            }
        });
        Button bplus = (Button) findViewById(R.id.buttonadd);
        bplus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String exp = ans.getText().toString();
                ans.setText(exp + "+");
            }
        });

        Button bsubtract = (Button) findViewById(R.id.buttonsub);
        bsubtract.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String exp = ans.getText().toString();
                ans.setText(exp + "-");
            }
        });

        Button divide = (Button) findViewById(R.id.buttondiv);
        divide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String exp = ans.getText().toString();
                ans.setText(exp + "/");
            }
        });

        Button multiply = (Button) findViewById(R.id.buttonmul);
        multiply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String exp = ans.getText().toString();
                ans.setText(exp + "*");
            }
        });

        Button c = (Button) findViewById(R.id.buttonc);
        c.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String exp = ans.getText().toString();
                ans.setText("");
            }
        });

        Button equal = (Button) findViewById(R.id.buttonans);
        equal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int answer = 0;
                String a=ans.toString();
                String[] tokens=a.split(" ");

                switch (tokens[1].charAt(0)) {
                    case '+':
                        answer = Integer.parseInt(tokens[0])
                                + Integer.parseInt(tokens[2]);
                        break;
                    case '-':
                        answer = Integer.parseInt(tokens[0])
                                - Integer.parseInt(tokens[2]);
                        break;
                    case '*':
                        answer = Integer.parseInt(tokens[0])
                                * Integer.parseInt(tokens[2]);
                        break;
                    case '/':
                        answer = Integer.parseInt(tokens[0])
                                / Integer.parseInt(tokens[2]);
                }

                ans.setText(answer);
            }

        });
    }
}
